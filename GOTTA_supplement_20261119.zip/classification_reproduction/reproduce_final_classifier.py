"""Reproduce the validation-selected candidate from one public feature CSV.

Example: python reproduce_final_classifier.py --features corrected_features_with_split.csv --output rerun
The feature sentinel values are retained exactly as supplied. No test score is
used to select either the classifier family or training-sample balancing.
"""
import argparse
import hashlib
import json
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score
from sklearn.neighbors import NearestCentroid
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

FEATURES = ['n_obs','median_mag','mean_mag','std_mag','amp','mad','p90_p10','skew','kurt','slope','lag1_autocorr','period','phase_cycles_covered','phase_points_per_cycle','phase_amp','phase_mad','phase_iqr','phase_skew','phase_kurt','phase_lag1_circular','phase_smooth_resid_std','phase_slope_mean_abs','phase_slope_asym','phase_peak_count','phase_trough_count','phase_peak_prominence_1','phase_peak_prominence_2','phase_peak_prom_ratio','phase_peak_sep','phase_width_half_amp','phase_width_deep_amp','phase_deep_run_frac_circular','phase_deep_run_count_circular']

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--features',required=True,type=Path); parser.add_argument('--output',required=True,type=Path); a=parser.parse_args()
    a.output.mkdir(parents=True,exist_ok=True)
    d=pd.read_csv(a.features,dtype={'source_id':str})
    tr=d[d.split.eq('train')]; va=d[d.split.eq('validation')]; te=d[d.split.eq('test')]
    x=lambda z:z[FEATURES].replace([np.inf,-np.inf],np.nan)
    def pipe(clf,scale=False):
        return make_pipeline(SimpleImputer(strategy='median'),*([StandardScaler()] if scale else []),clf)
    candidates={
        'nearest centroid':pipe(NearestCentroid(),True),
        'logistic regression':pipe(LogisticRegression(max_iter=3000,random_state=1),True),
        'linear discriminant analysis':pipe(LinearDiscriminantAnalysis(),True),
        'random forest':pipe(RandomForestClassifier(n_estimators=300,random_state=1,n_jobs=1)),
        'gradient boosting':pipe(GradientBoostingClassifier(random_state=1))}
    validation=[]
    for name,m in candidates.items():
        m.fit(x(tr),tr.label)
        validation.append({'candidate':name,'balanced_accuracy':balanced_accuracy_score(va.label,m.predict(x(va)))})
    family=max(validation,key=lambda z:z['balanced_accuracy'])['candidate']
    pd.DataFrame(validation).to_csv(a.output/'candidate_validation.csv',index=False)
    balanced=[]; models={}; orders={}
    for method in ['natural','undersampling','oversampling']:
        rows=tr; rng=np.random.default_rng(1)
        groups=[g.index.to_numpy() for _,g in tr.groupby('label')]
        if method!='natural':
            n=(min if method=='undersampling' else max)(map(len,groups))
            ids=np.concatenate([rng.choice(v,n,replace=False) if method=='undersampling' else np.r_[v,rng.choice(v,n-len(v),replace=True)] for v in groups])
            rows=tr.loc[ids]
        m=clone(candidates[family]).fit(x(rows),rows.label);models[method]=m;orders[method]=rows
        balanced.append({'strategy':method,'balanced_accuracy':balanced_accuracy_score(va.label,m.predict(x(va)))})
    chosen=max(balanced,key=lambda z:z['balanced_accuracy'])['strategy']; m=models[chosen]
    pd.DataFrame(balanced).to_csv(a.output/'balance_validation.csv',index=False)
    orders[chosen][['source_id','label']].assign(fit_row=lambda z:np.arange(len(z))).to_csv(a.output/'actual_fitted_row_order.csv',index=False)
    pred=m.predict(x(te))
    te[['source_id','label']].assign(y_pred=pred).to_csv(a.output/'test_predictions.csv',index=False)
    joblib.dump(m,a.output/'model.joblib')
    info={'classifier':family,'balancing':chosen,'features':FEATURES,'source_sha256':hashlib.sha256(a.features.read_bytes()).hexdigest(),'accuracy':accuracy_score(te.label,pred),'balanced_accuracy':balanced_accuracy_score(te.label,pred),'macro_f1':f1_score(te.label,pred,average='macro')}
    (a.output/'model_specification.json').write_text(json.dumps(info,indent=2));print(json.dumps(info,indent=2))

if __name__=='__main__':main()
