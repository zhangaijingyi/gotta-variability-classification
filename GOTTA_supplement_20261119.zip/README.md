# GOTTA manuscript supplement

Version: 2026-11-19

Repository: https://github.com/zhangaijingyi/gotta-variability-classification

This accompanying supplement updates the classification environment and period controls. It is a separately versioned submission package; its preparation does not update the existing GitHub v1.0.1 archive.

## Classification

Use CPython 3.12.3 and `requirements_classification.txt`. The verified classifier uses scikit-learn 1.6.1, not the 1.4.2 listed in the earlier environment record. Reconstruction recovers all 556 validation and 695 test predictions. The original natural training distribution and validation-based model selection are retained.

```bash
python reproduce_final_classifier.py --features corrected_features_with_split.csv --output rerun
python reproduce_period_sensitivity.py --output-dir period_rerun
```

`classification_reproduction/historical_environment_reproduction/` contains the fitted model, explicit feature order, fitted training-row order, validation selection tables and predictions. `final_classifier.joblib` is the same reconstructed main classifier. Only load trusted joblib files in a compatible environment.

`period_robustness_summary.csv`, `period_robustness_predictions.csv` and `period_robustness_by_class.csv` use that same classifier. The saved perturbation features allow these predictions to be reconstructed without raw photometry. `period_perturbation_metadata.csv` retains both baseline phase drift and epoch-dependent displacement. The two observing-window sentinel values and all shape definitions are unchanged.

`phase_default_sources.csv` gives the twelve default-feature sources, including observation counts, occupied bins, magnitudes and source assignments. Selection and cadence eligibility products are retained from the previous supplement.

## GP and cadence products

The existing point-level GP validation and cadence products are unchanged. To regenerate the GP summaries from released derived data:

```bash
python reproduce_gp_validation_summary.py
```

The classification environment correction does not constitute a new GP fit or a verification of the GP environment. Raw GOTTA photometry remains restricted under the collaboration's data-release policy and is not included.

## Citation and reuse

Citation metadata is supplied in `CITATION.cff`. No general reuse or redistribution license is granted by this package. Permission must be obtained from the relevant rights holders; contact Jingyi Zhang at jyzhang@bao.ac.cn. Public access for inspection does not itself grant a reuse license. See `docs/LICENSE_NOTE.md`.

`SHA256SUMS.txt` lists the checksums of the distributed files. Earlier analysis scripts are retained for context; the two commands above are the canonical classification and period-control reproduction procedures for this version.
