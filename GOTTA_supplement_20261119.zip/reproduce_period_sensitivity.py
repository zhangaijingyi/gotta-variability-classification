"""Apply the same main classifier to the supplied period-perturbation features."""
from pathlib import Path
import argparse
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score,balanced_accuracy_score,f1_score

def main():
    p=argparse.ArgumentParser();p.add_argument('--input-dir',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args();a.output_dir.mkdir(parents=True,exist_ok=True)
    root=a.input_dir
    cols=json.loads((root/'classification_reproduction/historical_environment_reproduction/model_specification.json').read_text())['features']
    model=joblib.load(root/'final_classifier.joblib')
    data=pd.read_csv(root/'corrected_features_with_split.csv',dtype={'source_id':str});base=data[data.split.eq('test')].set_index('source_id')
    x=lambda d:d[cols].replace([np.inf,-np.inf],np.nan)
    baseline=dict(zip(base.index,model.predict(x(base))))
    features=pd.read_csv(root/'period_robustness_features.csv',dtype={'source_id':str}).pivot(index=['case','source_id'],columns='feature',values='perturbed_value')
    metadata=pd.read_csv(root/'period_perturbation_metadata.csv',dtype={'source_id':str}).set_index(['case','source_id'])
    rows=[];predictions=[];byclass=[]
    for case,g in features.groupby(level='case'):
        g=g.droplevel('case');ev=base.loc[g.index].copy();ev[g.columns]=g
        pred=model.predict(x(ev));reference=ev.index.map(baseline).to_numpy();meta=metadata.loc[case].loc[ev.index]
        if case in ['catalog','refolded_catalog']:assert np.array_equal(pred,reference)
        rows.append({'case':case,'factor':float(meta.period_factor.iloc[0]),'n':len(ev),'accuracy':accuracy_score(ev.label,pred),'balanced_accuracy':balanced_accuracy_score(ev.label,pred),'macro_f1':f1_score(ev.label,pred,average='macro'),'prediction_retention':float(np.mean(pred==reference)),'n_changed':int(np.sum(pred!=reference)),'median_drift_cycles':float(meta.accumulated_drift_cycles.median())})
        for sid,y,z,b in zip(ev.index,ev.label,pred,reference):predictions.append({'source_id':sid,'case':case,'y_true':y,'y_pred':z,'catalog_prediction':b})
        for lab in sorted(ev.label.unique()):
            ix=ev.label.eq(lab).to_numpy();byclass.append({'case':case,'label':lab,'n':int(ix.sum()),'recall':float(np.mean(pred[ix]==ev.label.to_numpy()[ix]))})
    pd.DataFrame(rows).to_csv(a.output_dir/'period_robustness_summary.csv',index=False)
    pd.DataFrame(predictions).to_csv(a.output_dir/'period_robustness_predictions.csv',index=False)
    pd.DataFrame(byclass).to_csv(a.output_dir/'period_robustness_by_class.csv',index=False)

if __name__=='__main__':main()
